function load() {
    $.ajax({
        url: "http://127.0.0.1:5000",
        dataType: "json",
        success: function(data) {
            var i = 0;
            var jsonObj = [];
            for (i; i < (data['deauthAttacks'].length); i++) {

                item = {}
                item["sl_no"] = i + 1;
                timestamp = data['deauthAttacks'][i].timestamp;
                item["date"] = new Date(timestamp * 1000);
                item["Packets"] = data['deauthAttacks'][i].type;
                item["Vmac"] = data['deauthAttacks'][i].victim;
                item["Rmac"] = data['deauthAttacks'][i].router;
                item["Rcom"] = data['deauthAttacks'][i].routerInfo['company_name'];
                

                jsonObj.push(item);

            }
            


            const Template = ({ sl_no, date, Packets, Vmac, Rmac, Rcom }) => `
        <tr>
          <th scope="row">${sl_no}</th>
          <td>${date}</td>
          <td>${Packets}</td>
          <td>${Vmac}</td>
          <td>${Rmac}</td>
          <td>${Rcom}</td>
        </tr>
        `;
            $('.data').html(jsonObj.map(Template).join(''));


            // add here
            $('.one').html(jsonObj[0].date);
        }
    });



    // $.getJSON("./assets/js/Data.json", function(data) {
    //     var i = 0;
    //     var jsonObj = [];
    //     for (i; i < (data['deauthAttacks'].length); i++) {

    //         item = {}
    //         item["sl_no"] = i + 1;
    //         timestamp = data['deauthAttacks'][i].timestamp;
    //         item["date"] = new Date(timestamp * 1000);
    //         item["Packets"] = data['deauthAttacks'][i].type;
    //         item["Vmac"] = data['deauthAttacks'][i].victim;
    //         item["Rmac"] = data['deauthAttacks'][i].router;

    //         jsonObj.push(item);

    //     }


    //     const Template = ({ sl_no, date, Packets, Vmac, Rmac }) => `
    //     <tr>
    //       <th scope="row">${sl_no}</th>
    //       <td>${date}</td>
    //       <td>${Packets}</td>
    //       <td>${Vmac}</td>
    //       <td>${Rmac}</td>
    //     </tr>
    //     `;
    //     $('.data').html(jsonObj.map(Template).join(''));


    //     // add here
    //     $('.one').html(jsonObj[0].date);

    // }).fail(function() {
    //     console.log("An error has occurred.");
    // });
}
